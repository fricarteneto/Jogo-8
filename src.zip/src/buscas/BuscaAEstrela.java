package buscas;

public class BuscaAEstrela {

}
