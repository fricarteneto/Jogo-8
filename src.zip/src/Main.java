import buscas.BuscaEmLargura;
import buscas.BuscaEmProfundidade;


public class Main {

	public static void main(String args[]){
		/*
		BuscaEmLargura largura = new BuscaEmLargura();
		System.out.println(largura.iniciarBusca());
		*/
		BuscaEmProfundidade profundidade = new BuscaEmProfundidade();
		System.out.println(profundidade.iniciarBusca());
		
	}
}
